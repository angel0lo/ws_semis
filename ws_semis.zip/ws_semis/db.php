<?php
$host = 'localhost'; // Server host (default: localhost)
$user = 'root'; // Default username for WAMP
$password = ''; // Default password (leave blank unless you've set one)
$dbname = 'my_website'; // Replace with your database name

// Create a connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
