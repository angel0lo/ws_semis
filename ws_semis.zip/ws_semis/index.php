<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>I LOVE OTTERS</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <header class="home-header">
        <h1>Welcome to Our Otter Paradise</h1>
        <p>Explore the playful and charming world of otters!</p>
    </header>

    <nav>
        <ul>
            <li><a href="index.php?page=home">Home</a></li>
            <li><a href="index.php?page=about">About</a></li>
            <li><a href="index.php?page=contact">Contact</a></li>
        </ul>
    </nav>

    <main>
        <?php
        if (isset($_GET['page'])) {
            $page = htmlspecialchars($_GET['page']);
            if ($page === "home") {
                include 'home.php';
            } elseif ($page === "about") {
                include 'about.php';
            } elseif ($page === "contact") {
                include 'contact.php';
            } else {
                echo "<p>Page not found.</p>";
            }
        } else {
            include 'home.php'; // Default to Home Page
        }
        ?>
    </main>

    <footer>
        <p>&copy; 2024 I Love Otters ❤.</p>
    </footer>

    <button id="scrollTop" style="display: none;">⬆ Top</button>

    <script>
        document.getElementById('scrollTop').addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        document.addEventListener('scroll', function() {
            const scrollTopButton = document.getElementById('scrollTop');
            if (window.scrollY > 300) {
                scrollTopButton.style.display = 'block';
            } else {
                scrollTopButton.style.display = 'none';
            }
        });
    </script>
</body>
</html>
