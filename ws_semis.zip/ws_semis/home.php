<section>
    <h1>Welcome to Our Website</h1>
    <p>
    Dive into the world of otters, where cuteness meets curiosity! Our website is your ultimate hub for all things otter - from fascinating facts and playful behavior to their role in ecosystems and how you can help protect them.
    Whether you're here to marvel at their antics, learn more about their habitat, or explore ways to support conservation, you've found the right place. Let's celebrate these adorable, aquatic wonders together! 🌊❤️
    </p>
    <img src="home.jpg" alt="otter" style="max-width: 100%; border-radius: 10px;">
</section>
