<section>
    <h1>About Otters</h1>
    <p>
        Otters are playful aquatic mammals known for their intelligence and sociable nature. Found in various parts of the world, otters are an important part of the ecosystem, keeping aquatic environments balanced.
    </p>

    <div class="otter-facts">
        <h2>Fun Facts About Otters</h2>
        <ul>
            <li>Otters are excellent swimmers and can hold their breath underwater for up to 8 minutes.</li>
            <li>Sea otters use rocks to crack open shellfish, making them one of the few tool-using animals.</li>
            <li>Otters often float in groups, called "rafts," while holding hands to stay together.</li>
        </ul>
    </div>

    <div class="otter-gallery">
        <h2>Otter Gallery</h2>
        <div class="gallery">
            <div class="gallery-item">
                <img src="otter1.jpg" alt="Placeholder for otter image 1">
                <p>Otters playing in the water.</p>
            </div>
            <div class="gallery-item">
                <img src="otter2.jpg" alt="Placeholder for otter image 2">
                <p>A cute otter holding a rock.</p>
            </div>
            <div class="gallery-item">
                <img src="otter3.jpg" alt="Placeholder for otter image 3">
                <p>Raft of otters floating together.</p>
            </div>
        </div>
    </div>
</section>
