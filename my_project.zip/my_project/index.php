<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <link rel="stylesheet" href="style.css" id="stylesheet-link">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="schoolLogo.png" alt="School Logo" class="logo">
                <h1>Sta. Rita Elementary School</h1>
            </div>
            <div class="auth-buttons">
                <button onclick="location.href='login.php'" class="auth-button login">Login</button>
                <button onclick="location.href='register.php'" class="auth-button register">Register</button>
            </div>
        </div>
    </header>

    <div class="container">
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                </ul>
            </nav>
        </aside>

        <main>
            <section class="hero">
                <div class="hero-content">
                    <div class="hero-text">
                        <h2>Welcome to Our School!</h2>
                        <p>We are thrilled to welcome you to <strong>Sta. Rita Elementary School</strong>...</p>
                    </div>
                    <div class="hero-image-container">
                        <img src="school.jpg" alt="school" class="hero-image">
                    </div>
                </div>
            </section>

            <section class="facilities">
                <h3>Facilities</h3>
                <div class="scroll-container">
                    <img src="school2.jpg" alt="School 2" class="facility-image">
                    <img src="school3.jpg" alt="School 3" class="facility-image">
                    <img src="school4.jpg" alt="School 4" class="facility-image">
                    <img src="school5.jpg" alt="School 5" class="facility-image">
                    <img src="school6.jpg" alt="School 6" class="facility-image">
                    <img src="school7.jpg" alt="School 7" class="facility-image">
                    <img src="school8.jpg" alt="School 8" class="facility-image">
                </div>
            </section>

            <section class="enrollment">
                <h3>Enrollment</h3>
                <form action="enroll.php" method="POST" class="enrollment-form">
                    <label for="student_name">Student Name:</label>
                    <input type="text" id="student_name" name="student_name" required>

                    <label for="grade_level">Grade Level:</label>
                    <input type="text" id="grade_level" name="grade_level" required>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>

                    <label for="contact_number">Contact Number:</label>
                    <input type="text" id="contact_number" name="contact_number" required>

                    <button type="submit">Enroll</button>
                </form>
            </section>
        </main>
    </div>

    <footer>
        <p>Phone: (123) 456-7890</p>
        <p>Email: info@staritaelementary.com</p>
    </footer>
</body>
</html>
