<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="loading.css"> 
</head>
<body>

    <div id="progress-bar-container">
        <div id="progress-bar"></div>
    </div>

    <script>
        let progress = 0;
        let interval = setInterval(function() {
            if (progress >= 100) {
                clearInterval(interval);
                window.location.href = "dashboard.php"; 
            } else {
                progress++;
                document.getElementById("progress-bar").style.width = progress + "%";
            }
        }, 30); 
    </script>

</body>
</html>
