<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div id="loading-bar" class="loading-bar" style="display: none;"></div>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="schoolLogo.png" alt="School Logo" class="logo">
                <h1>Welcome to the Dashboard</h1>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <h2>Welcome, <?php echo $_SESSION['name']; ?>!</h2>
            <p>You are logged in to the dashboard.</p>
            <a href="logout.php">Logout</a>
        </div>
    </main>
</body>
</html>
