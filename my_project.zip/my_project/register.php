<?php
include('db.php'); // Include the database connection script

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);

    // Execute the query
    if ($stmt->execute()) {
        echo "Registration successful!";
        // Redirect to login page or home
        header("Location: login.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo-title">
            <img src="schoolLogo.png" alt="School Logo" class="logo">
            <h1>Sta. Rita Elementary School</h1>
        </div>
    </header>
    <main>
        <div class="auth-form register">
            <h2>Register</h2>
            <form action="register.php" method="POST">
                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" required>
               
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
               
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
               
                <button type="submit">Register</button>
                <button type="button" class="back-button" onclick="window.history.back();">Back</button>
            </form>            
           
        </div>
    </main>
</body>
</html>