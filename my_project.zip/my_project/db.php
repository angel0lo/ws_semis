<?php
$servername = "localhost"; // usually localhost for WAMP
$username = "root"; // default WAMP MySQL username
$password = ""; // default WAMP MySQL password (empty)
$dbname = "school"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
