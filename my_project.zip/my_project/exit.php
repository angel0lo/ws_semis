<?php
session_start();
session_unset(); // Clear session data
session_destroy(); // Destroy session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Too Many Attempts</title>
</head>
<body>
    <h1>Too Many Failed Login Attempts</h1>
    <p>You have exceeded the maximum number of login attempts. Please try again later.</p>
</body>
</html>
