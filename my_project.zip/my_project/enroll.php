<?php
include('db_connect.php');

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_name = $_POST['student_name'];
    $grade_level = $_POST['grade_level'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];

    // Sanitize and validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    // Check if the student is already enrolled
    $stmt = $conn->prepare("SELECT * FROM enrollments WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('You are already enrolled.'); window.location.href = 'index.php';</script>";
        exit;
    }

    // Insert student enrollment data into the database
    $stmt = $conn->prepare("INSERT INTO enrollments (student_name, grade_level, email, contact_number) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $student_name, $grade_level, $email, $contact_number);
    $stmt->execute();

    echo "<script>alert('Enrollment successful!'); window.location.href = 'index.php';</script>";
    exit;
}
?>
