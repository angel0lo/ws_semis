<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="style.css" id="stylesheet-link">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="schoolLogo.png" alt="School Logo" class="logo">
                <h1>Sta. Rita Elementary School</h1>
            </div>
            <div class="auth-buttons">
                <button onclick="location.href='login.html'" class="auth-button login">Login</button>
                <button onclick="location.href='register.html'" class="auth-button register">Register</button>
            </div>
        </div>
    </header>
    
    <div class="container">
        <aside class="sidebar">
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                </ul>
            </nav>
        </aside>

        <main>
            <section class="about">
                <h2>About Us</h2>
                <p>Welcome to <strong>Sta. Rita Elementary School</strong>, a vibrant learning community dedicated to fostering the growth and development of young minds. Located in Sta. Rita Karsada Batangas City, our school serves students from Grade 1 to 6 and is committed to providing a nurturing and dynamic educational experience.</p>
                
                <h3>Our Mission</h3>
                <p>At <strong>Sta. Rita Elementary School</strong>, our mission is to inspire a love of learning, promote academic excellence, and build strong, responsible citizens. We strive to create an inclusive environment where every student feels valued, supported, and motivated to reach their full potential.</p>
                
                <h3>Our Vision</h3>
                <p>Our vision is to be a leading educational institution where innovative teaching methods, diverse learning opportunities, and strong community partnerships come together to empower students. We aim to cultivate lifelong learners who are curious, confident, and equipped to thrive in a rapidly changing world.</p>
                
                <h3>Our Values</h3>
                <ul>
                    <li><strong>Respect:</strong> We honor the individuality of each student and foster a culture of mutual respect and understanding.</li>
                    <li><strong>Integrity:</strong> We promote honesty, responsibility, and ethical behavior in all aspects of school life.</li>
                    <li><strong>Excellence:</strong> We are committed to high academic standards and continuous improvement, both for students and staff.</li>
                    <li><strong>Collaboration:</strong> We believe in the power of teamwork and actively engage parents, students, and the community in the educational process.</li>
                </ul>

                <h3>Our Programs</h3>
                <p>Our school offers a comprehensive curriculum that balances core academic subjects with a rich array of extracurricular activities.</p>

                <h3>Our Community</h3>
                <p>At <strong>Sta. Rita Elementary School</strong>, we pride ourselves on building a strong, supportive community. We work closely with families and local organizations to enhance our educational programs and create a positive, inclusive environment for all.</p>

                <h3>Join Us</h3>
                <p>We invite you to explore what makes <strong>Sta. Rita Elementary School</strong> a special place for learning and growth. Whether you are a prospective student or a new family, we look forward to welcoming you to our school and working together to make this an extraordinary experience for every child.</p>
            </section>
        </main>
    </div>

    <footer class="contact-bar">
        <div class="contact-info">
            <p><strong>Contact Us:</strong></p>
            <p>Phone: (123) 456-7890</p>
            <p><a href="https://www.facebook.com/DepEdTayoSRES109593/" target="_blank">Follow us on Facebook</a></p>
            <p>Email: info@staritaelementary.com</p>
            <p>Address: Sta. Rita Karsada Batangas City</p>
        </div>
    </footer>
</body>
</html>
