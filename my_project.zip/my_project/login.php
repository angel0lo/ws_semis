<?php
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('db_connect.php');  // Include database connection

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate credentials with MySQLi
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];  // Store user session
        $_SESSION['name'] = $user['name'];   // Store user name for the dashboard

        // Redirect to loading page after successful login
        header("Location: loading.php");
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="schoolLogo.png" alt="School Logo" class="logo">
                <h1>Sta. Rita Elementary School</h1>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <form action="login.php" method="POST" class="auth-form">
                <h2>Login</h2>

                <?php if (isset($error)): ?>
                    <p class="error"><?= $error; ?></p>
                <?php endif; ?>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>
                <button type="button" class="back-button" onclick="window.history.back();">Back</button>
            </form>
        </div>
    </main>
</body>
</html>
