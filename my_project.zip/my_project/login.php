<?php
session_start();

// Initialize login attempts count if not already set
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
}

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Process the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('db_connect.php');  

    $email = $_POST['email'];
    $password = $_POST['password'];

    // If max attempts reached, exit
    if ($_SESSION['attempts'] >= 3) {
        echo "<script>alert('You have exceeded the maximum number of login attempts. Please try again later.');</script>";
        exit;
    }

    // Validate credentials with MySQLi
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    // Check if user exists
    if ($user) {
        // Validate password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];  // Store user session
            $_SESSION['name'] = $user['name'];   // Store user name for the dashboard
            $_SESSION['attempts'] = 0;           // Reset attempts on successful login

            // Redirect to loading.php instead of dashboard.php
            header("Location: loading.php");
            exit;
        } else {
            $_SESSION['attempts']++;  // Increment the attempt counter
            echo "<script>alert('Incorrect password. You have " . (3 - $_SESSION['attempts']) . " attempts left.');</script>";
        }
    } else {
        $_SESSION['attempts']++;  // Increment the attempt counter
        echo "<script>alert('Username not found. You have " . (3 - $_SESSION['attempts']) . " attempts left.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="schoolLogo.png" alt="School Logo" class="logo">
                <h1>Sta. Rita Elementary School</h1>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <form action="login.php" method="POST" class="auth-form">
                <h2>Login</h2>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>
                <button type="button" class="back-button" onclick="window.history.back();">Back</button>
            </form>
        </div>
    </main>
</body>
</html>  
